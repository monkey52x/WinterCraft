---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Dust
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
categories:
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Fluix Dust

<ItemImage id="fluix_dust" scale="4" />

A <ItemLink id="fluix_crystal" /> that has been crushed by an <ItemLink id="inscriber" />. Used in the production of
several AE2 machines and components.

## Recipe

<RecipeFor id="fluix_dust" />
